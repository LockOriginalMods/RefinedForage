package com.LockOriginalMods.refinedforage.common.blocks;

import com.LockOriginalMods.refinedforage.RefinedForage;
import net.minecraft.block.BlockState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Rarity;

public  class ItemCustom extends Item {
    public ItemCustom() {
        super(new Properties().group(RefinedForage.REFINEDFORAGE_GROUP).maxDamage(9).rarity(Rarity.COMMON));
        setRegistryName("hammer");
    }

    public boolean hasContainerItem() {
        return true;
    }

    @Override
    public ItemStack getContainerItem(ItemStack itemstack) {
        ItemStack reveal = new ItemStack(this);
        reveal.setDamage(itemstack.getDamage() + 1);
        if (reveal.getDamage() >= reveal.getMaxDamage()) {
            return ItemStack.EMPTY;
        }
        return reveal;
    }

    @Override
    public boolean isRepairable(ItemStack itemstack) {
        return false;
    }

    @Override
    public int getItemEnchantability() {
        return 0;
    }

    @Override
    public int getUseDuration(ItemStack itemstack) {
        return 0;
    }

    @Override
    public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
        return 1F;
    }
}