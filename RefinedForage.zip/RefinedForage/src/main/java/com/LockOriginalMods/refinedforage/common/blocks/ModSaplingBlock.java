package com.LockOriginalMods.refinedforage.common.blocks;

import net.minecraft.block.SaplingBlock;
import net.minecraft.block.trees.Tree;

public class ModSaplingBlock extends SaplingBlock {
    public ModSaplingBlock(Tree treeIn, Properties properties) {
        super(treeIn, properties);
    }
}
