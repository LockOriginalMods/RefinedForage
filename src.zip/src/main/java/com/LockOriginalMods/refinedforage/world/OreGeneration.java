package com.LockOriginalMods.refinedforage.world;

import com.LockOriginalMods.refinedforage.core.init.BlockInit;

import net.minecraft.block.BlockState;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.GenerationStage;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.OreFeatureConfig;
import net.minecraft.world.gen.feature.template.RuleTest;
import net.minecraft.world.gen.placement.Placement;
import net.minecraft.world.gen.placement.TopSolidRangeConfig;
import net.minecraftforge.common.world.BiomeGenerationSettingsBuilder;
import net.minecraftforge.event.world.BiomeLoadingEvent;

public class OreGeneration
{
    public static void generateOres(final BiomeLoadingEvent event)
    {
        if(!event.getCategory().equals(Biome.Category.PLAINS) || event.getCategory().equals(Biome.Category.BEACH) || event.getCategory().equals(Biome.Category.DESERT)
                || event.getCategory().equals(Biome.Category.EXTREME_HILLS) || event.getCategory().equals(Biome.Category.FOREST) || event.getCategory().equals(Biome.Category.ICY)
                || event.getCategory().equals(Biome.Category.JUNGLE) || event.getCategory().equals(Biome.Category.MESA) || event.getCategory().equals(Biome.Category.MUSHROOM)
                || event.getCategory().equals(Biome.Category.OCEAN) || event.getCategory().equals(Biome.Category.RIVER) || event.getCategory().equals(Biome.Category.SAVANNA)
                || event.getCategory().equals(Biome.Category.TAIGA))
            generateOre(event.getGeneration(), OreFeatureConfig.FillerBlockType.BASE_STONE_OVERWORLD, BlockInit.SLATE_TIN.get().getDefaultState(), 5, 1, 30, 10);
        generateOre(event.getGeneration(), OreFeatureConfig.FillerBlockType.BASE_STONE_OVERWORLD, BlockInit.SLATE_SILVER.get().getDefaultState(), 5, 1, 30, 10);
        generateOre(event.getGeneration(), OreFeatureConfig.FillerBlockType.BASE_STONE_OVERWORLD, BlockInit.SLATE_REDSTONE.get().getDefaultState(), 5, 1, 15, 10);
        generateOre(event.getGeneration(), OreFeatureConfig.FillerBlockType.BASE_STONE_OVERWORLD, BlockInit.SLATE_LEAD.get().getDefaultState(), 5, 1, 30, 10);
        generateOre(event.getGeneration(), OreFeatureConfig.FillerBlockType.BASE_STONE_OVERWORLD, BlockInit.SLATE_IRON.get().getDefaultState(), 5, 1, 30, 110);
        generateOre(event.getGeneration(), OreFeatureConfig.FillerBlockType.BASE_STONE_OVERWORLD, BlockInit.SLATE_GOLD.get().getDefaultState(), 5, 1, 30, 10);
        generateOre(event.getGeneration(), OreFeatureConfig.FillerBlockType.BASE_STONE_OVERWORLD, BlockInit.SLATE_EMERALD.get().getDefaultState(), 5, 1, 15, 10);
        generateOre(event.getGeneration(), OreFeatureConfig.FillerBlockType.BASE_STONE_OVERWORLD, BlockInit.SLATE_DIAMOND.get().getDefaultState(), 5, 1, 15, 10);
        generateOre(event.getGeneration(), OreFeatureConfig.FillerBlockType.BASE_STONE_OVERWORLD, BlockInit.SLATE_COPPER.get().getDefaultState(), 5, 1, 30, 10);
        generateOre(event.getGeneration(), OreFeatureConfig.FillerBlockType.BASE_STONE_OVERWORLD, BlockInit.SLATE_COAL.get().getDefaultState(), 5, 1, 30, 10);
        generateOre(event.getGeneration(), OreFeatureConfig.FillerBlockType.BASE_STONE_OVERWORLD, BlockInit.SLATE.get().getDefaultState(), 5, 19, 30, 10);

        {

        }
    }
    private static void generateOre(BiomeGenerationSettingsBuilder settings, RuleTest fillerType, BlockState state,
                                    int veinSize, int  minHeight, int maxHeight, int amount)
    {
        settings.withFeature(GenerationStage.Decoration.UNDERGROUND_ORES,
                Feature.ORE.withConfiguration(new OreFeatureConfig(fillerType, state, veinSize))
                        .withPlacement(Placement.RANGE.configure(new TopSolidRangeConfig(minHeight, 0, maxHeight)))
                        .square().func_242731_b(amount));
    }
}
