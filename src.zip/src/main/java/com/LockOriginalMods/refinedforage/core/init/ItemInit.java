package com.LockOriginalMods.refinedforage.core.init;

import com.LockOriginalMods.refinedforage.RefinedForage;
import com.LockOriginalMods.refinedforage.common.blocks.WildberriesBush;
import com.LockOriginalMods.refinedforage.common.items.BatteryItem;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.*;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Properties;

public class ItemInit {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, RefinedForage.MOD_ID);

    public static void init() {
        ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus());
    }

    public static final RegistryObject<Item> COPPER_INGOT = ITEMS.register("copper_ingot", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<BlockItem> FORESTWILDBERRIES_BUSH = ITEMS.register("forestwildberries_bush",
            () -> new BlockItem(BlockInit.FORESTWILDBERRIES_BUSH.get(), new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP).food(FoodInit.WILDBERRIES)));

    public static final RegistryObject<Item> TRIDENT_STICK = ITEMS.register("trident_stick", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<Item> TRIDENT_TOP = ITEMS.register("trident_top", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<Item> GOLDEN_CHERRY = ITEMS.register("golden_cherry", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP).food(FoodInit.GOLDEN_CHERRY)));

    public static final RegistryObject<Item> CHERRY = ITEMS.register("cherry", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP).food(FoodInit.CHERRY)));

    public static final RegistryObject<BatteryItem> BATTERY = ITEMS.register("battery", BatteryItem::new);

    public static final RegistryObject<Item> SOLAR_CELL = ITEMS.register("solar_cell", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<Item> SOLARIDUSTRIAL_CELL = ITEMS.register("solarindustrial_cell", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<Item> SOLARADVANCED_CELL = ITEMS.register("solaradvanced_cell", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<Item> SOLARULTIMATE_CELL = ITEMS.register("solarultimate_cell", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<Item> SOLARQuantum_CELL = ITEMS.register("solarquantum_cell", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<Item> SOLARSpectral_CELL = ITEMS.register("solarspectral_cell", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<Item> COPPER_WIRE = ITEMS.register("copper_wire", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<Item> BRONZE_INGOT = ITEMS.register("bronze_ingot", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<Item> LEAD_INGOT = ITEMS.register("lead_ingot", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<Item> SILVER_INGOT = ITEMS.register("silver_ingot", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<Item> TIN_INGOT = ITEMS.register("tin_ingot", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<Item> STEEL_INGOT = ITEMS.register("steel_ingot", ()
            -> new Item(new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<BlockItem> SLATE = ITEMS.register("slate",
            () -> new BlockItem(BlockInit.SLATE.get(), new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<BlockItem> SLATE_BRICK = ITEMS.register("slate_brick",
            () -> new BlockItem(BlockInit.SLATE_BRICK.get(), new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<BlockItem> SLATE_SILVER = ITEMS.register("slate_silver",
            () -> new BlockItem(BlockInit.SLATE_SILVER.get(), new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<BlockItem> SLATE_TIN = ITEMS.register("slate_tin",
            () -> new BlockItem(BlockInit.SLATE_TIN.get(), new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<BlockItem> SLATE_COPPER = ITEMS.register("slate_copper",
            () -> new BlockItem(BlockInit.SLATE_COPPER.get(), new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<BlockItem> SLATE_LEAD = ITEMS.register("slate_lead",
            () -> new BlockItem(BlockInit.SLATE_LEAD.get(), new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));

    public static final RegistryObject<BlockItem> COBBLED_SLATE = ITEMS.register("cobbled_slate",
            () -> new BlockItem(BlockInit.COBBLED_SLATE.get(), new Item.Properties().group(RefinedForage.REFINEDFORAGE_GROUP)));
}





