package com.LockOriginalMods.refinedforage.core.init;

import com.LockOriginalMods.refinedforage.RefinedForage;
import com.LockOriginalMods.refinedforage.common.blocks.WildberriesBush;
import com.LockOriginalMods.refinedforage.common.items.BatteryItem;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.*;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Properties;

public class ItemInit {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, RefinedForage.MOD_ID);

    public static void init() {
        ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus());
    }

    public static final RegistryObject<Item> COPPER_INGOT = ITEMS.register("copper_ingot", ()
            -> new Item(new Item.Properties().group(ItemGroup.MATERIALS)));

    public static final RegistryObject<BlockItem> FORESTWILDBERRIES_BUSH = ITEMS.register("forestwildberries_bush",
            () -> new BlockItem(BlockInit.FORESTWILDBERRIES_BUSH.get(), new Item.Properties().group(ItemGroup.FOOD).food(FoodInit.WILDBERRIES)));

    public static final RegistryObject<Item> TRIDENT_STICK = ITEMS.register("trident_stick", ()
            -> new Item(new Item.Properties().group(ItemGroup.FOOD)));

    public static final RegistryObject<Item> TRIDENT_TOP = ITEMS.register("trident_top", ()
            -> new Item(new Item.Properties().group(ItemGroup.FOOD)));

    public static final RegistryObject<Item> GOLDEN_CHERRY = ITEMS.register("golden_cherry", ()
            -> new Item(new Item.Properties().group(ItemGroup.FOOD).food(FoodInit.GOLDEN_CHERRY)));

    public static final RegistryObject<Item> CHERRY = ITEMS.register("cherry", ()
            -> new Item(new Item.Properties().group(ItemGroup.FOOD).food(FoodInit.CHERRY)));

    public static final RegistryObject<BatteryItem> BATTERY = ITEMS.register("battery", BatteryItem::new);

    public static final RegistryObject<Item> SOLAR_CELL = ITEMS.register("solar_cell", ()
            -> new Item(new Item.Properties().group(ItemGroup.MATERIALS)));

    public static final RegistryObject<Item> COPPER_WIRE = ITEMS.register("copper_wire", ()
            -> new Item(new Item.Properties().group(ItemGroup.MATERIALS)));
}
